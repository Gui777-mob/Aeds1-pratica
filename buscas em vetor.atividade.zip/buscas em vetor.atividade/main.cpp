/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/main.cc to edit this template
 */

/* 
 * File:   main.cpp
 * Author: 2024.1.08.011
 *
 * Created on 9 de abril de 2024, 17:26
 */

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <fstream>
#include <time.h>
#include <math.h>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int numero[1000];
    int i=0,numeroaleatorio=0; 
    int opcao=-1;
   
    srand(time(NULL));
while(i<1000){    
    numeroaleatorio=100+rand()%101;
        numero[i] = numeroaleatorio;
       
      cout<<numero[i]<<endl;
       i++;
}while(opcao!=0 and opcao <=3){
    cout<<"escolha uma opção :"<<endl<<"opção1=informar se o valor existe "<<"opção2=contar quantas vezes o valor aparece e sua posição"<<endl"contar quantas vezes o valor aparece em um intervalo"<<endl;

}
   
    return 0;
}

